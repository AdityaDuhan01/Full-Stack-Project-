Name: Aditya Duhan

UID:25BDS80001

Group:B

Experiment:Admin Dashboard using CSS Grid and Theme Switching

Approach:-
-This experiment focuses on building a responsive admin dashboard using CSS Grid layout.
-HTML was used for structure, CSS Grid for layout management, and JavaScript for theme switching.

